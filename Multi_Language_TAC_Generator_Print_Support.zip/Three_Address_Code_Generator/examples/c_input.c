int a;
int b;
int c;
a = b + c * 2;
