int i = 0;
while (i < 3) {
    i++;
}
for (i = 0; i < 3; i++) {
    a = a + i;
}
