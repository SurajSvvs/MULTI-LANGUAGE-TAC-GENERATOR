public class Demo {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        if (a < b) {
            a = a + 5;
        } else {
            a = a - 5;
        }
    }
}
