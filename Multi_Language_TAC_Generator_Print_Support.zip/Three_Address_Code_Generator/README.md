# Multi-Language Three Address Code Generator

A Python Compiler Design Lab project that accepts **normal arithmetic expressions** and a practical **subset of C, C++, and Java**, then generates Three-Address Code (TAC).

## Input modes

### 1. Normal expression (no language wrapper needed)

Input:
```text
a + b * c
```

Output:
```text
t1 = b * c
t2 = a + t1
result = t2
```

### 2. C / C++ source subset

```cpp
#include <iostream>
using namespace std;

int main() {
    int a = 10;
    int b = 20;
    if (a < b) {
        a = a + 5;
    } else {
        a = a - 5;
    }
    return 0;
}
```

### 3. Java source subset

```java
public class Demo {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        if (a < b) {
            a = a + 5;
        } else {
            a = a - 5;
        }
    }
}
```

The front end removes common include/import/package, class, and `main` wrappers, then processes the supported statements.

## Supported constructs

- Normal arithmetic expressions and assignments
- C/C++/Java-style simple variable declarations (`int`, `float`, `double`, `char`)
- Assignments and semicolon-separated statements
- `if`, `if-else`, `while`, and simple `for` loops
- Relational operators `<`, `>`, `<=`, `>=`, `==`, `!=`
- Basic `&&` and `||` condition strings
- Prefix/postfix `++` and `--`
- Parentheses, unary plus/minus, arithmetic precedence
- Basic output statements: `printf`, `cout <<`, `System.out.print/println` (emitted as TAC-style `print` instructions)
- `//` and `/* ... */` comments
- Tkinter GUI and command-line interface

## Important limitations

This is an educational **subset parser**, not a complete standards-compliant C, C++, or Java compiler. It does not currently implement output/input statements (`printf`, `cout`, `System.out.println`, `Scanner`), methods/functions, arrays, pointers, objects, `switch`, `do-while`, `break`, `continue`, return-value semantics, ternary expressions, or full short-circuit/backpatching behavior. For best results, use arithmetic statements and simple control flow only. `return 0;` in a C/C++ `main` wrapper is ignored by preprocessing only if removed manually; if it remains, remove it from the sample before generating TAC.

## Run the GUI

1. Extract the ZIP.
2. Open the project folder in VS Code.
3. Run:

```powershell
python src\gui.py
```

Or double-click `run_gui.bat`.

## Run from terminal

```powershell
python src\tac_generator.py "a + b * c"
python src\tac_generator.py --file examples\control_flow.c
```

## Run tests

```powershell
python -m unittest discover -s tests -v
```
