# Three Address Code Generator for Arithmetic Expressions

## 1. Abstract

A compiler translates a source program into a form that can be understood and processed by another system. Intermediate code generation is an important phase in a compiler because it represents source operations in a simpler form. This project, **Three Address Code Generator for Arithmetic Expressions**, accepts arithmetic expressions, simple assignments, and a limited subset of C statements and converts it into Three-Address Code (TAC). TAC uses simple instructions in which each instruction performs one operation, usually with at most three addresses: two operands and one result. The implementation tokenizes the input, parses it using a recursive-descent parser, respects operator precedence and parentheses, and creates temporary variables for intermediate results. It supports addition, subtraction, multiplication, division, modulo, exponentiation, unary signs, identifiers, and numeric literals. The project provides both a command-line interface and a graphical interface built with Tkinter. It uses Python's standard library, so no additional package installation is required. Test cases verify precedence, parentheses, unary minus, and invalid input. The project demonstrates lexical analysis, syntax analysis, and intermediate code generation in a compact and easy-to-run form.

## 2. Introduction

Compiler design includes several stages, such as lexical analysis, syntax analysis, semantic analysis, intermediate code generation, optimization, and target-code generation. Three-Address Code is a common intermediate representation. It breaks complex expressions into smaller instructions, making later optimization and translation easier.

For example, `a = b + c * d` must multiply `c` and `d` before adding `b`. The generated code is:

```text
t1 = c * d
t2 = b + t1
a = t2
```

This project focuses on the intermediate-code-generation stage for arithmetic expressions.

## 3. Problem Statement

Writing intermediate code manually for complex arithmetic expressions is error-prone. A tool is needed to accept an expression, apply operator precedence and parentheses correctly, and output equivalent Three-Address Code using temporary variables.

## 4. Objectives

1. Accept arithmetic expressions and assignment statements as input.
2. Recognize identifiers, numbers, operators, and parentheses.
3. Respect operator precedence and associativity.
4. Generate TAC instructions with unique temporary variables.
5. Detect malformed expressions and display useful error messages.
6. Provide a simple interface that is easy to run on Windows.

## 5. Proposed System

The user enters an expression in the GUI or command line. The tokenizer converts the input into tokens. The parser checks the expression structure and emits TAC instructions as operations are recognized. Each intermediate operation receives a temporary variable such as `t1` or `t2`. The final result is assigned to the requested variable, or to `result` if no assignment target is supplied.

## 6. System Requirements

### Hardware
- A standard laptop or desktop computer
- At least 2 GB RAM recommended
- A few megabytes of free storage

### Software
- Windows 10/11
- Python 3.10 or newer
- VS Code or any text editor (optional)

No third-party Python packages are required.

## 7. Compiler Concepts Used

### 7.1 Lexical Analysis

The tokenizer recognizes numeric literals, identifiers, operators, parentheses, and whitespace. Whitespace is ignored.

### 7.2 Syntax Analysis

A recursive-descent parser validates the expression and applies precedence rules. Multiplication, division, and modulo are handled before addition and subtraction. Parentheses allow the user to group operations.

### 7.3 Intermediate Code Generation

The parser emits one operation per instruction and stores intermediate results in temporary variables. This converts a complex expression into a sequence of simple operations.

### 7.4 Error Handling

Invalid characters, missing operands, unexpected tokens, and unmatched parentheses produce error messages rather than TAC output.

## 8. Algorithm

1. Read the expression from the user or a file.
2. Tokenize the input.
3. Check whether it is an assignment or a standalone expression.
4. Parse the expression according to operator precedence.
5. For each operation, create a new temporary variable.
6. Emit a TAC instruction for the operation.
7. Emit the final assignment to the target variable, or `result`.
8. Display the generated code.

## 9. Input and Output Examples

### Example 1: Operator precedence

Input:

```text
a = b + c * d
```

Output:

```text
t1 = c * d
t2 = b + t1
a = t2
```

### Example 2: Parentheses

Input:

```text
x = (a + b) * (c - d)
```

Output:

```text
t1 = a + b
t2 = c - d
t3 = t1 * t2
x = t3
```

### Example 3: Unary operator

Input:

```text
result = -a + b / 2
```

Output:

```text
t1 = -a
t2 = b / 2
t3 = t1 + t2
result = t3
```

### Example 4: Invalid input

Input:

```text
a = b + * c
```

Output:

```text
Error: Expected a number, identifier, or '(' ...
```

The exact position is included in the actual error message.

## 10. Testing

The included unit tests cover:
- Multiplication before addition
- Parenthesized expressions
- Standalone arithmetic expressions
- Unary minus
- Invalid operator sequences
- Missing closing parentheses

Run the tests from the project root:

```bat
python -m unittest discover -s tests -v
```

## 11. Applications

- Learning compiler phases
- Demonstrating intermediate representation
- Understanding operator precedence
- Teaching expression parsing
- Serving as a base for a larger compiler project

## 12. Limitations

The project supports arithmetic expressions, simple variable declarations, and assignments separated by semicolons. It is not a complete C compiler and does not yet support functions, arrays, pointers, control-flow statements, type checking, or machine-code generation. It generates TAC but does not execute it.

## 13. Future Enhancements

- Support multiple statements and variables
- Add quadruple, triple, and indirect-triple tables
- Add constant folding and simple TAC optimization
- Add a parse-tree or syntax-tree visualization
- Extend the grammar to relational and Boolean expressions

## 14. Conclusion

The project demonstrates how arithmetic expressions and a small subset of straight-line C code can be converted into Three-Address Code using tokenization and recursive-descent parsing. It correctly handles operator precedence, parentheses, and unary signs, and produces temporary variables for intermediate results. The GUI and command-line interfaces make it convenient to demonstrate and test. The implementation provides a practical foundation for understanding intermediate code generation in compiler design.

## 15. References

1. A. V. Aho, M. S. Lam, R. Sethi, and J. D. Ullman, *Compilers: Principles, Techniques, and Tools*, 2nd ed., Pearson, 2006.
2. Python Software Foundation, “Python 3 Documentation,” https://docs.python.org/3/
3. Tkinter documentation, https://docs.python.org/3/library/tkinter.html
