import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from tac_generator import generate_tac, TACError


class TestTACGenerator(unittest.TestCase):
    def test_arithmetic_precedence(self):
        self.assertEqual(generate_tac("a = b + c * d"), "t1 = c * d\nt2 = b + t1\na = t2")

    def test_if_else(self):
        out = generate_tac("int a=10; int b=20; if (a < b) { a = a + 5; } else { a = a - 5; }")
        self.assertIn("if a < b goto L1", out)
        self.assertIn("goto L2", out)
        self.assertIn("L1:", out)
        self.assertIn("L2:", out)
        self.assertIn("L3:", out)
        self.assertIn("a = t", out)

    def test_if_without_else(self):
        out = generate_tac("if (a != b) a = a + 1;")
        self.assertIn("if a != b goto L1", out)
        self.assertIn("L2:", out)

    def test_while_loop(self):
        out = generate_tac("int i=0; while (i < 3) { i++; }")
        self.assertIn("L1:", out)
        self.assertIn("if i < 3 goto L2", out)
        self.assertIn("goto L1", out)

    def test_for_loop(self):
        out = generate_tac("for (i = 0; i < 3; i++) { a = a + i; }")
        self.assertIn("if i < 3 goto L2", out)
        self.assertIn("i = t", out)
        self.assertIn("goto L1", out)


    def test_plain_expression_without_assignment(self):
        self.assertEqual(generate_tac("a + b * c"), "t1 = b * c\nt2 = a + t1\nresult = t2")

    def test_plain_assignment_without_semicolon(self):
        self.assertEqual(generate_tac("x = a + b"), "t1 = a + b\nx = t1")


    def test_cpp_wrapper(self):
        out = generate_tac("#include <iostream>\nusing namespace std;\nint main() { int a = 10; int b = 20; if (a < b) { a = a + 5; } }")
        self.assertIn("if a < b goto", out)
        self.assertIn("a = 10", out)
        self.assertIn("a = t", out)

    def test_java_wrapper(self):
        out = generate_tac("public class Demo { public static void main(String[] args) { int a = 10; if (a > 0) { a = a + 1; } } }")
        self.assertIn("if a > 0 goto", out)
        self.assertIn("a = 10", out)


    def test_c_printf(self):
        out = generate_tac('int a = 5; printf("%d", a);')
        self.assertIn("a = 5", out)
        self.assertIn("print a", out)

    def test_cpp_cout(self):
        out = generate_tac('#include <iostream>\nusing namespace std;\nint main() { int a = 5; cout << a << endl; }')
        self.assertIn("a = 5", out)
        self.assertIn("print a", out)

    def test_java_println(self):
        out = generate_tac('public class Demo { public static void main(String[] args) { int a = 5; System.out.println(a); } }')
        self.assertIn("a = 5", out)
        self.assertIn("print a", out)

    def test_bad_expression(self):
        with self.assertRaises(TACError):
            generate_tac("a = b + * c")

    def test_missing_brace(self):
        with self.assertRaises(TACError):
            generate_tac("if (a < b) { a = 1;")


if __name__ == "__main__":
    unittest.main()
