@echo off
cd /d "%~dp0"
python src\tac_generator.py
pause
