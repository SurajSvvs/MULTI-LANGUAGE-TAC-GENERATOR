"""Simple Tkinter GUI for the Three Address Code Generator."""
import tkinter as tk
from tkinter import ttk, messagebox
from tac_generator import generate_tac, TACError


EXAMPLES = [
    "a = b + c * d",
    "a + b * c",
    "x = (a + b) * (c - d)",
    "result = -a + b / 2",
    "p = a ** 2 + b % 3",
]


class TACApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Three Address Code Generator")
        self.geometry("760x540")
        self.minsize(620, 440)
        self.configure(padx=18, pady=18)
        self._build_ui()

    def _build_ui(self):
        ttk.Label(
            self,
            text="Three Address Code Generator",
            font=("Segoe UI", 18, "bold")
        ).pack(anchor="w")
        ttk.Label(
            self,
            text="Input mode: normal arithmetic expressions OR a supported subset of C code (if-else, while, for)."
        ).pack(anchor="w", pady=(4, 14))

        ttk.Label(self, text="Input expression:").pack(anchor="w")
        self.input_box = tk.Text(self, height=4, font=("Consolas", 12), wrap="word")
        self.input_box.pack(fill="x", pady=(4, 8))
        self.input_box.insert("1.0", "a = b + c * d")

        row = ttk.Frame(self)
        row.pack(fill="x", pady=(0, 12))
        ttk.Button(row, text="Generate TAC", command=self.generate).pack(side="left")
        ttk.Button(row, text="Clear", command=self.clear).pack(side="left", padx=8)
        ttk.Label(row, text="Example:").pack(side="left", padx=(16, 4))
        self.example_var = tk.StringVar(value=EXAMPLES[0])
        combo = ttk.Combobox(
            row, textvariable=self.example_var, values=EXAMPLES, state="readonly", width=30
        )
        combo.pack(side="left", fill="x", expand=True)
        combo.bind("<<ComboboxSelected>>", self.load_example)

        ttk.Label(self, text="Generated three-address code:").pack(anchor="w")
        self.output_box = tk.Text(
            self, height=12, font=("Consolas", 12), wrap="none",
            state="disabled", background="#f4f6f8"
        )
        self.output_box.pack(fill="both", expand=True, pady=(4, 8))
        ttk.Label(
            self,
            text="Normal input: a + b * c. C input: declarations, assignments, if-else, while, for, comparisons, ++/--."
        ).pack(anchor="w")

    def load_example(self, _event=None):
        self.input_box.delete("1.0", "end")
        self.input_box.insert("1.0", self.example_var.get())

    def generate(self):
        source = self.input_box.get("1.0", "end").strip()
        try:
            output = generate_tac(source)
        except TACError as exc:
            messagebox.showerror("Invalid expression", str(exc))
            return
        self.output_box.configure(state="normal")
        self.output_box.delete("1.0", "end")
        self.output_box.insert("1.0", output)
        self.output_box.configure(state="disabled")

    def clear(self):
        self.input_box.delete("1.0", "end")
        self.output_box.configure(state="normal")
        self.output_box.delete("1.0", "end")
        self.output_box.configure(state="disabled")


if __name__ == "__main__":
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    TACApp().mainloop()
