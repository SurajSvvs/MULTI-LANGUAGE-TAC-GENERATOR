"""Three Address Code Generator for arithmetic expressions and a small C subset."""
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import List, Optional


class TACError(ValueError):
    """Raised when source code is invalid or outside the supported subset."""


@dataclass
class Token:
    kind: str
    value: str
    position: int


TOKEN_RE = re.compile(
    r"(?P<NUMBER>(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?)"
    r"|(?P<IDENT>[A-Za-z_][A-Za-z0-9_]*)"
    r"|(?P<OP>\+\+|--|==|!=|<=|>=|&&|\|\||\*\*|[+\-*/%=(){};,<>!])"
    r"|(?P<SPACE>\s+)"
)


def tokenize(source: str) -> List[Token]:
    tokens: List[Token] = []
    i = 0
    while i < len(source):
        m = TOKEN_RE.match(source, i)
        if not m:
            raise TACError(f"Unexpected character {source[i]!r} at position {i}.")
        kind, value = m.lastgroup, m.group()
        if kind != "SPACE":
            tokens.append(Token(kind or "", value, i))
        i = m.end()
    tokens.append(Token("EOF", "", len(source)))
    return tokens


class Parser:
    def __init__(self, source: str):
        self.tokens = tokenize(source)
        self.i = 0
        self.code: List[str] = []
        self.temp = 0
        self.label = 0

    def cur(self) -> Token:
        return self.tokens[self.i]

    def peek(self, offset=1) -> Token:
        return self.tokens[min(self.i + offset, len(self.tokens) - 1)]

    def accept(self, value: str) -> bool:
        if self.cur().value == value:
            self.i += 1
            return True
        return False

    def expect(self, value: str) -> Token:
        if not self.accept(value):
            t = self.cur()
            raise TACError(f"Expected {value!r} at position {t.position}, found {t.value!r}.")
        return self.tokens[self.i - 1]

    def new_temp(self) -> str:
        self.temp += 1
        return f"t{self.temp}"

    def new_label(self) -> str:
        self.label += 1
        return f"L{self.label}"

    def emit(self, line: str) -> None:
        self.code.append(line)

    def parse(self) -> str:
        if self.cur().kind == "EOF":
            raise TACError("Please enter C code or an arithmetic expression.")
        while self.cur().kind != "EOF":
            if self.accept(";"):
                continue
            self.statement()
        if not self.code:
            raise TACError("No supported statements were found.")
        return "\n".join(self.code)

    def statement(self) -> None:
        if self.cur().value == "{":
            self.block()
        elif self.cur().value == "if":
            self.if_statement()
        elif self.cur().value == "while":
            self.while_statement()
        elif self.cur().value == "for":
            self.for_statement()
        elif self.cur().value == "else":
            t = self.cur()
            raise TACError(f"Unexpected 'else' at position {t.position}.")
        else:
            self.simple_statement()

    def block(self) -> None:
        self.expect("{")
        while self.cur().value != "}":
            if self.cur().kind == "EOF":
                raise TACError("Missing closing '}' for block.")
            self.statement()
        self.expect("}")

    def if_statement(self) -> None:
        self.expect("if")
        self.expect("(")
        condition = self.condition()
        self.expect(")")
        true_label = self.new_label()
        false_label = self.new_label()
        end_label = self.new_label()
        self.emit(f"if {condition} goto {true_label}")
        self.emit(f"goto {false_label}")
        self.emit(f"{true_label}:")
        self.statement()
        if self.accept("else"):
            self.emit(f"goto {end_label}")
            self.emit(f"{false_label}:")
            self.statement()
            self.emit(f"{end_label}:")
        else:
            self.emit(f"{false_label}:")
            # end_label intentionally unused when there is no else

    def while_statement(self) -> None:
        self.expect("while")
        start_label = self.new_label()
        body_label = self.new_label()
        end_label = self.new_label()
        self.emit(f"{start_label}:")
        self.expect("(")
        condition = self.condition()
        self.expect(")")
        self.emit(f"if {condition} goto {body_label}")
        self.emit(f"goto {end_label}")
        self.emit(f"{body_label}:")
        self.statement()
        self.emit(f"goto {start_label}")
        self.emit(f"{end_label}:")

    def for_statement(self) -> None:
        self.expect("for")
        self.expect("(")
        # init; condition; update
        if self.cur().value != ";":
            self.simple_statement(expect_semicolon=False)
        self.expect(";")
        start_label = self.new_label()
        body_label = self.new_label()
        update_label = self.new_label()
        end_label = self.new_label()
        self.emit(f"{start_label}:")
        if self.cur().value != ";":
            cond = self.condition()
            self.emit(f"if {cond} goto {body_label}")
            self.emit(f"goto {end_label}")
        else:
            self.emit(f"goto {body_label}")
        self.expect(";")
        update_tokens = []
        depth = 0
        while not (self.cur().value == ")" and depth == 0):
            if self.cur().kind == "EOF":
                raise TACError("Missing ')' in for loop.")
            tok = self.cur()
            if tok.value == "(":
                depth += 1
            elif tok.value == ")":
                depth -= 1
            update_tokens.append(tok.value)
            self.i += 1
        self.expect(")")
        self.emit(f"{body_label}:")
        # Store body for proper placement of update code after body.
        body_start = len(self.code)
        self.statement()
        body_code = self.code[body_start:]
        del self.code[body_start:]
        self.emit(f"goto {update_label}")
        self.emit(f"{update_label}:")
        if update_tokens:
            self._compile_simple_text(" ".join(update_tokens), allow_decl=False)
        self.emit(f"goto {start_label}")
        self.emit(f"{end_label}:")
        self.code.extend([])

    def simple_statement(self, expect_semicolon=True) -> None:
        start = self.i
        # gather until top-level semicolon, or until block/EOF when no semicolon is allowed
        if self.cur().value in ("int", "float", "double", "char", "long", "short", "unsigned", "signed", "const"):
            self._parse_declaration()
            if expect_semicolon:
                self.expect(";")
            return

        if self.cur().value == "return":
            raise TACError("'return' is not supported in this TAC generator yet.")

        depth = 0
        parts = []
        while self.cur().kind != "EOF":
            v = self.cur().value
            if depth == 0 and v in (";", "}", ")"):
                break
            if v == "(":
                depth += 1
            elif v == ")":
                if depth == 0:
                    break
                depth -= 1
            parts.append(self.cur())
            self.i += 1
        if not parts:
            t = self.cur()
            raise TACError(f"Expected a statement at position {t.position}.")
        text = " ".join(t.value for t in parts)
        self._compile_simple_text(text)
        if expect_semicolon and self.cur().value != "" and self.cur().kind != "EOF":
            self.expect(";")

    def _parse_declaration(self) -> None:
        type_tokens = []
        while self.cur().value in ("const", "unsigned", "signed", "long", "short", "int", "float", "double", "char"):
            type_tokens.append(self.cur().value)
            self.i += 1
        # Parse comma-separated declarators up to semicolon.
        chunks = []
        current = []
        depth = 0
        while self.cur().kind != "EOF":
            v = self.cur().value
            if depth == 0 and v == ";":
                break
            if v == "(":
                depth += 1
            elif v == ")":
                depth -= 1
            if v == "," and depth == 0:
                chunks.append(current)
                current = []
            else:
                current.append(v)
            self.i += 1
        chunks.append(current)
        for chunk in chunks:
            if not chunk:
                continue
            text = " ".join(chunk)
            m = re.fullmatch(r"([A-Za-z_]\w*)\s*(?:=\s*(.+))?", text, re.S)
            if not m:
                raise TACError(f"Unsupported declaration: {text!r}")
            name, rhs = m.group(1), m.group(2)
            if rhs is not None:
                self._compile_assignment(name, rhs)

    def _compile_simple_text(self, text: str, allow_decl=True) -> None:
        text = text.strip()
        # Normalized output statement; emits an explicit TAC-style I/O instruction.
        if text == "print":
            self.emit("print")
            return
        if text.startswith("print "):
            self.emit("print " + text[len("print "):].strip())
            return
        # postfix/prefix increment/decrement
        m = re.fullmatch(r"(\+\+|--)\s*([A-Za-z_]\w*)|([A-Za-z_]\w*)\s*(\+\+|--)", text)
        if m:
            name = m.group(2) or m.group(3)
            op = m.group(1) or m.group(4)
            symbol = "+" if op == "++" else "-"
            self._compile_assignment(name, f"{name} {symbol} 1")
            return
        m = re.fullmatch(r"([A-Za-z_]\w*)\s*=\s*(.+)", text, re.S)
        if m:
            self._compile_assignment(m.group(1), m.group(2))
            return
        # Bare arithmetic expression
        value, generated = self._compile_expression(text)
        self.code.extend(generated)
        self.emit(f"result = {value}")

    def _compile_assignment(self, target: str, rhs: str) -> None:
        value, generated = self._compile_expression(rhs)
        self.code.extend(generated)
        self.emit(f"{target} = {value}")

    def _compile_expression(self, text: str):
        parser = ExprParser(text, self.temp)
        value = parser.expression()
        if parser.cur().kind != "EOF":
            t = parser.cur()
            raise TACError(f"Unexpected token {t.value!r} in arithmetic expression.")
        self.temp = parser.temp
        return value, parser.code

    def condition(self) -> str:
        # Supports comparisons and logical && / || in simple conditions.
        left = self.arithmetic_operand()
        if self.cur().value in ("<", ">", "<=", ">=", "==", "!="):
            op = self.cur().value
            self.i += 1
            right = self.arithmetic_operand()
            cond = f"{left} {op} {right}"
        else:
            cond = left
        while self.cur().value in ("&&", "||"):
            op = self.cur().value
            self.i += 1
            right = self.condition_atom()
            cond = f"{cond} {op} {right}"
        return cond

    def condition_atom(self) -> str:
        left = self.arithmetic_operand()
        if self.cur().value in ("<", ">", "<=", ">=", "==", "!="):
            op = self.cur().value
            self.i += 1
            right = self.arithmetic_operand()
            return f"{left} {op} {right}"
        return left

    def arithmetic_operand(self) -> str:
        # Parse arithmetic until a relational/logical delimiter.
        start = self.i
        depth = 0
        while self.cur().kind != "EOF":
            v = self.cur().value
            if depth == 0 and v in (")", ";", "<", ">", "<=", ">=", "==", "!=", "&&", "||"):
                break
            if v == "(":
                depth += 1
            elif v == ")":
                if depth == 0:
                    break
                depth -= 1
            self.i += 1
        tokens = self.tokens[start:self.i]
        if not tokens:
            raise TACError(f"Expected condition operand at position {self.cur().position}.")
        text = " ".join(t.value for t in tokens)
        value, generated = self._compile_expression(text)
        self.code.extend(generated)
        return value


class ExprParser:
    def __init__(self, source: str, temp_start=0):
        self.tokens = tokenize(source)
        self.i = 0
        self.code: List[str] = []
        self.temp = temp_start

    def cur(self):
        return self.tokens[self.i]

    def accept(self, value):
        if self.cur().value == value:
            self.i += 1
            return True
        return False

    def new_temp(self):
        self.temp += 1
        return f"t{self.temp}"

    def emit(self, left, op, right):
        t = self.new_temp()
        self.code.append(f"{t} = {left} {op} {right}")
        return t

    def expression(self):
        value = self.term()
        while self.cur().value in ("+", "-"):
            op = self.cur().value
            self.i += 1
            value = self.emit(value, op, self.term())
        return value

    def term(self):
        value = self.unary()
        while self.cur().value in ("*", "/", "%"):
            op = self.cur().value
            self.i += 1
            value = self.emit(value, op, self.unary())
        return value

    def unary(self):
        if self.accept("+"):
            return self.unary()
        if self.accept("-"):
            operand = self.unary()
            t = self.new_temp()
            self.code.append(f"{t} = -{operand}")
            return t
        return self.power()

    def power(self):
        value = self.primary()
        if self.accept("**"):
            value = self.emit(value, "**", self.unary())
        return value

    def primary(self):
        t = self.cur()
        if t.kind in ("NUMBER", "IDENT"):
            self.i += 1
            return t.value
        if self.accept("("):
            value = self.expression()
            if not self.accept(")"):
                raise TACError(f"Expected ')' at position {self.cur().position}.")
            return value
        raise TACError(f"Expected a number, identifier, or '(' at position {t.position}; found {t.value!r}.")


def _strip_comments(source: str) -> str:
    return re.sub(r"/\*.*?\*/|//[^\n]*", " ", source, flags=re.S)


def _prepare_source(source: str) -> str:
    """Remove common wrappers and normalize simple output statements for TAC."""
    source = _strip_comments(source)

    # Normalize common print/output statements into a small TAC pseudo-instruction.
    # These regexes target simple educational examples, not arbitrary nested C++ streams.
    def normalize_printf(match):
        args = match.group(1).strip()
        # printf("text"); -> print "text"; ; printf("%d", x); -> print x;
        pieces = [p.strip() for p in args.split(",")]
        if len(pieces) > 1:
            value = ", ".join(pieces[1:])
        else:
            value = pieces[0] if pieces else ""
        if value.startswith('"') and len(pieces) == 1:
            value = pieces[0]
        return f"print {value};" if value else "print;"

    def normalize_cout(match):
        expr = match.group(1).strip()
        parts = [p.strip() for p in re.split(r"<<", expr) if p.strip()]
        # Ignore quoted literal fragments and endl; retain variables/expressions.
        values = [p for p in parts if p != "endl" and not (p.startswith('"') and p.endswith('"'))]
        return f"print {', '.join(values)};" if values else "print;"

    source = re.sub(r"\bSystem\s*\.\s*out\s*\.\s*println\s*\(([^()]*)\)\s*;", normalize_printf, source)
    source = re.sub(r"\bSystem\s*\.\s*out\s*\.\s*print\s*\(([^()]*)\)\s*;", normalize_printf, source)
    source = re.sub(r"\b(?:printf|println|print)\s*\(([^()]*)\)\s*;", normalize_printf, source)
    source = re.sub(r"\bcout\s*<<\s*([^;]+);", normalize_cout, source)

    # Remove non-executable file-level directives commonly seen in examples.
    source = re.sub(r"(?m)^\s*#\s*include\b[^\n]*", "", source)
    source = re.sub(r"(?m)^\s*import\s+[\w.*]+\s*;", "", source)
    source = re.sub(r"(?m)^\s*package\s+[\w.]+\s*;", "", source)
    source = re.sub(r"(?m)^\s*using\s+namespace\s+std\s*;", "", source)

    # Remove common class/struct declaration headers, retaining their body.
    source = re.sub(
        r"\b(?:public\s+)?class\s+[A-Za-z_]\w*(?:\s+extends\s+[A-Za-z_]\w*)?\s*\{",
        "{", source
    )
    source = re.sub(r"\bstruct\s+[A-Za-z_]\w*\s*\{", "{", source)

    # Remove common entry-point headers while retaining their body.
    entry_patterns = [
        r"\bpublic\s+static\s+void\s+main\s*\(\s*String\s*\[\s*\]\s*\w+\s*\)\s*\{",
        r"\bpublic\s+static\s+void\s+main\s*\(\s*String\s*\.\.\.\s*\w+\s*\)\s*\{",
        r"\bint\s+main\s*\(\s*(?:void\s*)?\)\s*\{",
        r"\bint\s+main\s*\(\s*int\s+\w+\s*,\s*char\s*\*\s*\*\s*\w+\s*\)\s*\{",
        r"\bint\s+main\s*\(\s*int\s+\w+\s*,\s*char\s+\*\s*\w+\s*\[\s*\]\s*\)\s*\{",
    ]
    for pattern in entry_patterns:
        source = re.sub(pattern, "{", source)

    # If wrappers remain, remove one outermost block brace pair only when the
    # first non-whitespace character is '{' and its matching close is the end.
    source = source.strip()
    if source.startswith("{"):
        depth = 0
        match_index = None
        for idx, ch in enumerate(source):
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    match_index = idx
                    break
        if match_index == len(source) - 1:
            source = source[1:-1].strip()
    return source


def generate_tac(source: str) -> str:
    return Parser(_prepare_source(source)).parse()

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Generate TAC from arithmetic expressions and a small C subset.")
    parser.add_argument("expression", nargs="?", help='e.g. "a = b + c * d"')
    parser.add_argument("-f", "--file", help="Read source code from a file.")
    args = parser.parse_args()
    if args.expression and args.file:
        parser.error("Use either an expression argument or --file, not both.")
    try:
        if args.file:
            with open(args.file, encoding="utf-8") as f:
                source = f.read()
        elif args.expression:
            source = args.expression
        else:
            print("Enter C code or an arithmetic expression. Finish input with Ctrl+Z then Enter on Windows:")
            lines = []
            while True:
                try:
                    lines.append(input())
                except EOFError:
                    break
            source = "\n".join(lines)
        print("\nThree Address Code\n------------------")
        print(generate_tac(source))
    except (TACError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    import sys
    main()
